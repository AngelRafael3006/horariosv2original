
@extends("plantilla/plantilla1")

    @section("contenido1")
    @include("puestos2/tablahtml")
    
    @endsection