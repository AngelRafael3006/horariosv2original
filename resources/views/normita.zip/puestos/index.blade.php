
@extends("plantilla/plantilla1")

    @section("contenido1")
    @include("puestos/tablahtml")
    
    @endsection